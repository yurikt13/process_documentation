import { Component, OnInit } from '@angular/core';
import { UntypedFormBuilder, UntypedFormGroup, Validators } from '@angular/forms';
import { Router } from '@angular/router';
import { AuthenticationService } from '../../core/services/auth.service';
import { LAYOUT_MODE } from '../../layouts/layouts.model';
import { AuthService } from '../services/auth.service';
import { SWAL_AUTH_MESSAGES, SweetalertService } from 'src/app/common/sweetalert/sweetalert.service';
import { PAGES_RESOURCES } from 'src/helpers/pages.resources';

@Component({
  selector: 'app-login',
  templateUrl: './login.component.html',
  styleUrls: ['./login.component.scss']
})
export class LoginComponent implements OnInit {

  year: number = new Date().getFullYear();
  showNavigationArrows: any;
  loginForm!: UntypedFormGroup;
  submitted = false;
  error = '';
  returnUrl!: string;
  layout_mode!: string;
  fieldTextType!: boolean;
  isLogingIn: boolean = false

  constructor(private readonly formBuilder: UntypedFormBuilder,
              private readonly router: Router,
              private readonly authenticationService: AuthenticationService,
              private readonly authService: AuthService,
              private readonly sweetalertService: SweetalertService,
  ) {
    if (this.authenticationService.currentUserValue) {
      this.router.navigate(['/']);
    }
  }

  ngOnInit(): void {
    this.layout_mode = LAYOUT_MODE
    if (this.layout_mode === 'dark') {
      document.body.setAttribute("data-layout-mode", "dark");
    }
    this.loginForm = this.formBuilder.group({
      username: ['', [Validators.required]],
      password: ['', [Validators.required]],
    });
    document.body.setAttribute('data-layout', 'vertical');
  }

  get f() { return this.loginForm.controls; }

  onSubmit() {
    this.submitted = true;
    if (this.loginForm.invalid) {
      return;
    }
    this.isLogingIn = true
    const { username, password } = this.f
    const payload = {
      user: username.value,
      password: password.value
    }
    this.authService.signin(payload).subscribe((data: { token: string }) => {
      this.authService.setTokenInLocalStorage(data.token)
      this.isLogingIn = false
      this.router.navigate([PAGES_RESOURCES.dashboard()])
      this.sweetalertService.successmsg(SWAL_AUTH_MESSAGES.successLoggedIn)
    }, (error) => {
      this.sweetalertService.errormsg(error)
      this.isLogingIn = false
    })
  }

  toggleFieldTextType() {
    this.fieldTextType = !this.fieldTextType;
  }

}
