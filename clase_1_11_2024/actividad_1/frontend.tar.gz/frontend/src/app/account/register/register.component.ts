import { Component, OnInit } from '@angular/core';
import { UntypedFormBuilder, UntypedFormGroup, Validators } from '@angular/forms';
import { LAYOUT_MODE } from '../../layouts/layouts.model';
import { Router } from '@angular/router';
import { AuthService, SIGNUP_ATTRS } from '../services/auth.service';
import { SWAL_AUTH_MESSAGES, SweetalertService } from 'src/app/common/sweetalert/sweetalert.service';

@Component({
  selector: 'app-register',
  templateUrl: './register.component.html',
  styleUrls: ['./register.component.scss']
})

/**
 * Register Component
 */
export class RegisterComponent implements OnInit {

  // set the currenr year
  year: number = new Date().getFullYear();

  // Carousel navigation arrow show
  showNavigationArrows: any;

  layout_mode!: string;

  signupForm!: UntypedFormGroup;
  submitted = false;
  successmsg = false;
  error = '';

  constructor(private formBuilder: UntypedFormBuilder,
              private router: Router,
              private readonly authService: AuthService,
              private readonly sweetalertService: SweetalertService,
  ) { }

  ngOnInit(): void {
    this.layout_mode = LAYOUT_MODE
    if (this.layout_mode === 'dark') {
      document.body.setAttribute("data-layout-mode", "dark");
    }

    // Validation Set
    this.signupForm = this.formBuilder.group({
      name:     ['', Validators.required],
      lastName: ['', Validators.required],
      email:    ['', [Validators.required, Validators.email]],
      password: ['', [Validators.required]],
      type:     ['', [Validators.required]],
    });
    document.body.setAttribute('data-layout', 'vertical');
  }

  get f() { return this.signupForm.controls; }

  onSubmit() {
    this.submitted = true;
    if (this.signupForm.invalid) {
      return;
    } else {
      this.authService.signup(this.getPayload()).subscribe(data => {
        this.sweetalertService.successmsg(SWAL_AUTH_MESSAGES.successSignup)
        this.router.navigate(['/auth/login']);
      })
    }
  }

  getPayload(): SIGNUP_ATTRS {
    return {
      document: (Math.random() * 100000000).toFixed(),
      name: this.f["name"].value,
      lastName: this.f["lastName"].value,
      secondLastName: ".",
      password: this.f["password"].value,
      email: this.f["email"].value,
      celphone: (Math.random() * 100000000).toFixed(),
      roles: [ this.f["type"].value ]
    }
  }

}
