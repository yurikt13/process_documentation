import { HttpClient } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { BaseService } from 'src/app/services/base.service';
import { API_RESOURCES } from 'src/helpers/api.resources';
import { LocalStorageService, USER_LOCAL_STORAGE_KEYS } from './local-storage.service';
import { SUBJECT_ATTRS } from 'src/app/pages/commercial/services/ally.service';

export interface SIGNIN_ATTRS {
  user: string
  password: string
}

export interface SIGNUP_ATTRS {
  document?:       string
  name:            string
  lastName:        string
  secondLastName?: string
  email:           string
  celphone:        string
  password:        string
  roles?:          string[]
  isActive?:       boolean
}

@Injectable({
  providedIn: 'root'
})
export class AuthService extends BaseService {

  constructor(protected readonly httpClient: HttpClient, 
              private readonly localStorageService: LocalStorageService) {
    super(httpClient, localStorageService);
   }
  
  signup(payload: SIGNUP_ATTRS) {
    return this.httpPost(API_RESOURCES.authService.signup(), payload)
  }

  signin(payload: SIGNIN_ATTRS) {
    return this.httpPost(API_RESOURCES.authService.signin(), payload)
  }

  signout() {
    return this.httpPost(API_RESOURCES.authService.signout(), {})
  }

  isValidToken() {
    return this.httpGet(API_RESOURCES.authService.isAuthenticated())
  }

  me() {
    return this.httpGet(API_RESOURCES.authService.me())
  }

  getTokenInLocalStorage(): string | null {
    return this.localStorageService.getItem(USER_LOCAL_STORAGE_KEYS.TOKEN)
  }

  setTokenInLocalStorage(token: string) {
    this.localStorageService.setItem(USER_LOCAL_STORAGE_KEYS.TOKEN, token)
  }

  getAllSubjects() {
    return this.httpGet(API_RESOURCES.subjectsService.getAll())
  }
  
  createSubject(payload: SUBJECT_ATTRS) {
    return this.httpPost(API_RESOURCES.subjectsService.create(), payload)
  }

  getAllSubjectsByUser(user: string) {
    return this.httpGet(API_RESOURCES.subjectUserService.getAllByUser(user))
  }

  vinculateSubjectToUser(payload: { user: string, subject: string }) {
    return this.httpPost(API_RESOURCES.subjectUserService.create(), payload)
  }
  
}
