import { Injectable } from '@angular/core';
import { CryptoLibrary } from 'src/helpers/crypto.library';

export enum USER_LOCAL_STORAGE_KEYS {
  TOKEN = 'e33fa808-b64e-44a4-854a-73647212d856'
}

@Injectable({
  providedIn: 'root'
})
export class LocalStorageService {

  constructor(private readonly cryptoLibrary:CryptoLibrary) {}
  
  public setItem(key: USER_LOCAL_STORAGE_KEYS, value: { [key: string]: any } | string | number ): void {
    localStorage.setItem(key, this.cryptoLibrary.encrypt((this.getStringItemToStorage(value))))
  }

  public getItem(key: USER_LOCAL_STORAGE_KEYS): string | null {
    if(!localStorage.getItem(key)) return null
    return this.cryptoLibrary.decrypt(localStorage.getItem(key)!)
  }

  public removeItem(key: string): void {
    localStorage.removeItem(key)
  }

  private getStringItemToStorage(value: { [key: string]: any } | string | number): string {
    if(typeof value === 'object') return JSON.stringify(value)
    if(typeof value === 'number') return String(value)
    if(typeof value === 'string') return value
    return ""
  }
}

