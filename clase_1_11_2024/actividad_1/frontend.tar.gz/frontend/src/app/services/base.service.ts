import { Injectable } from '@angular/core';
import { Observable } from 'rxjs';
import { HttpClient, HttpHeaders } from '@angular/common/http';
import { environment } from 'src/environments/environment';
import { LocalStorageService, USER_LOCAL_STORAGE_KEYS } from '../account/services/local-storage.service';

export interface CUSTOM_OBJECT {
  [key: string]: any
}

export enum ACTIONS_FORM {
  CREATE = 'CREATE',
  UPDATE = 'UPDATE'
}

@Injectable({
  providedIn: 'root'
})
export class BaseService  {
  private apiUrl: string = environment.webService;

  constructor(protected readonly httpClient: HttpClient, 
              protected readonly localStorage: LocalStorageService) {}

  /**
   * Call Api GET method
   * @param  {string} path
   * @return {Observable<any>}
   */
  protected httpGet(path: string): Observable<any> {
    return this.httpClient.get(`${this.apiUrl}${path}`, this.getHttpHeaders()).pipe((data:any) => {
      return data
    })
  }

  /**
   * Call Api POST method
   * @param  {string} path
   * @return {Observable<any>}
   */
  protected httpPost(path: string, data: CUSTOM_OBJECT): Observable<any> {
    return this.httpClient.post(`${this.apiUrl}${path}`, data, this.getHttpHeaders()).pipe((data:any) => {
      return data
    })
  }

  /**
   * Call Api PATCH method
   * @param  {string} path
   * @return {Observable<any>}
   */
  protected httpPatch(path: string, data: object): Observable<any> {
    return this.httpClient.patch(`${this.apiUrl}${path}`, data, this.getHttpHeaders()).pipe((data:any) => {
      return data
    })
  }

  /**
   * Call Api GET method
   * @param  {string} path
   * @return {Observable<any>}
   */
  protected httpDelete(path: string): Observable<any> {
    return this.httpClient.delete(`${this.apiUrl}${path}`, this.getHttpHeaders()).pipe((data:any) => {
      return data
    })
  }

  private getHttpHeaders() {
    const token = this.localStorage.getItem(USER_LOCAL_STORAGE_KEYS.TOKEN)
    console.log(token, 'En la petición')
    const headers = new HttpHeaders({
      'Authorization': `Bearer ${token}`
    });
    return { headers }
  }

}
