import { Injectable } from '@angular/core';
import { Router, ActivatedRoute } from '@angular/router'

export { ActivatedRoute }

@Injectable({
  providedIn: 'root'
})

export class RouterService  {

  constructor(private readonly router:Router) {}

  navigate(path: string) {
    this.router.navigate([path]) 
  }

}
