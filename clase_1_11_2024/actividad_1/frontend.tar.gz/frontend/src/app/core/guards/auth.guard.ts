import { Injectable } from '@angular/core';
import { Router, CanActivate, ActivatedRouteSnapshot, RouterStateSnapshot } from '@angular/router';
import { AuthService } from 'src/app/account/services/auth.service';
import { PAGES_RESOURCES } from 'src/helpers/pages.resources';

@Injectable({ providedIn: 'root' })
export class AuthGuard implements CanActivate {
	constructor(
			private router: Router,
			private authService: AuthService
	) { }

    canActivate(route: ActivatedRouteSnapshot, state: RouterStateSnapshot): any {
			if(this.authService.getTokenInLocalStorage()) {
				return true
			} else {
				this.router.navigate([PAGES_RESOURCES.login()]);
				return false
			}
    }
}
