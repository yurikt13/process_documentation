import { MenuItem } from './menu.model';

export const MENU: MenuItem[] = [
  // {
  //   id: 2,
  //   label: 'Panel principal',
  //   icon: 'home',
  //   link: '/dashboard',
  // },
  // {
  //   id: 3,
  //   label: 'Observación',
  //   icon: 'grid',
  //   subItems: [
  //     {
  //       id: 4,
  //       label: 'Observabilidad',
  //       link: '/',
  //       parentId: 3,
  //       subItems: [
  //         {
  //           id: 7,
  //           label: 'CI',
  //           link: '/pages/observability/ci',
  //           parentId: 6,
  //         },
  //         {
  //           id: 8,
  //           label: 'Grupos',
  //           link: '/pages/observability/groups',
  //           parentId: 6,
  //         }
  //       ],
  //     }
  //   ]
  // },
  // {
  //   id: 4,
  //   label: 'Comercial',
  //   icon: 'box',
  //   subItems: [
  //     {
  //       id: 9,
  //       label: 'Aliados',
  //       link: '/pages/commercial/allies',
  //       parentId: 6,
  //     },
  //   ]
  // },
  {
    id: 4,
    label: 'Documentación',
    icon: 'box',
    subItems: [
      {
        id: 9,
        label: 'Documentación',
        link: '/pages/documentation',
        parentId: 6,
      },
    ]
  }
];
