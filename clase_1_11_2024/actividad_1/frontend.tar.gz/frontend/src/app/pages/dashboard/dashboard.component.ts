import { Component, OnInit } from '@angular/core';
import { DashboardService } from './services/dashboard.service';

@Component({
  selector: 'app-dashboard',
  templateUrl: './dashboard.component.html',
  styleUrls: ['./dashboard.component.scss']
})

/**
 *  Dashboard Component
 */
export class DashboardComponent implements OnInit {

  public name: string = ""
  public lastName: string = ""
  public users: any = {}
  showNavigationArrows: any;
  constructor(private readonly dashboardService:DashboardService) {}

  ngOnInit(): void {
    this.dashboardService.httpGet().subscribe(data => {
      this.users = data
    })
  }  

  send() {
    const payload = {
      name: this.name,
      lastName: this.lastName
    }
    this.dashboardService.httpPost(payload).subscribe(data => {
      const id = data['id']
      let obj: any = {}
      obj[id] = data['id'] = {
        id: +data['id'],
        name: data["name"],
        lastName: data["lastName"],
      }
      this.users = { ...this.users, ...obj }
      this.lastName = ""
      this.name = ""
    })
  }

  public usersKey() {
    return Object.keys(this.users)
  }

}
