import { Component } from '@angular/core'
import { FormBuilder, Validators } from '@angular/forms';
import { NgbModal } from '@ng-bootstrap/ng-bootstrap';

@Component({
  templateUrl: './create-edit-config-item-component.component.html',
  selector: 'app-create-edit-config-item-component',
  styleUrls: ['./create-edit-config-item-component.component.scss']
})

export class CreateEditConfigItemComponentComponent {
  
  public tagSubmitted!: boolean
  public submitted!: boolean
  public isAddingTags = false
  public tags: { name: string, value: string }[] = []
  public componentForm = this.formBuilder.group({
    name: ["", [Validators.required]],
    warning: ["", [Validators.required]],
    critical: ["", [Validators.required]],
    port: [""],
    unit: ["", [Validators.required]],
    tag: this.formBuilder.group({
      name: ["", [ Validators.required ]],
      value: ["", [ Validators.required ]]
    })
  })

  constructor(private modalService: NgbModal, 
              private formBuilder: FormBuilder) {}

  openOpen(content: any) {
    this.modalService.open(content,{ centered: true });
  }

  closeModal(modal: any) {

  }

  createComponent() {

  }

  hideAddTagInput() {
    this.isAddingTags = false
  }
  
  showAddTagInput() {
    this.isAddingTags = true
  }

  addTag() {
    this.tagSubmitted = true
    if(this.componentForm.controls['tag'].invalid) {
      return
    }
    const name = this.componentForm.controls['tag']['controls']['name'].value!
    const value = this.componentForm.controls['tag']['controls']['value'].value!

    this.tags.push({name, value})

    this.componentForm.controls['tag'].reset()
    this.tagSubmitted = false
  }

  get f() { return this.componentForm.controls }

  get ff() { return this.componentForm.controls['tag']['controls'] }

}