import { Component } from '@angular/core'

@Component({
	selector: 'app-component-groups',
	templateUrl: './component-groups.component.html',
	styleUrls: ['./component-groups.component.scss']
})

export class ComponentGroupsComponent {
	constructor() {
		
	}
}