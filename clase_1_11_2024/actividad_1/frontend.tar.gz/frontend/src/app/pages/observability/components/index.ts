import { ConfigItemComponentTableComponent }      from "./config-item-component-table/config-item-component-table.component";
import { CreateEditComponentGroupComponent }      from "./create-edit-component-group/create-edit-component-group.component";
import { CreateEditConfigItemComponentComponent } from "./create-edit-config-item-component/create-edit-config-item-component.component";

export const components = [
  ConfigItemComponentTableComponent,
  CreateEditComponentGroupComponent,
  CreateEditConfigItemComponentComponent,
]

export * from "./config-item-component-table/config-item-component-table.component";
export * from "./create-edit-component-group/create-edit-component-group.component";
export * from "./create-edit-config-item-component/create-edit-config-item-component.component";