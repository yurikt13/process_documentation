import { Component } from '@angular/core'

@Component({
  templateUrl: './config-item-component.component.html',
  styleUrls: ['./config-item-component.component.scss'],
  selector: 'app-config-item-component'
})

export class ConfigItemComponentComponent {
  constructor () {}
}