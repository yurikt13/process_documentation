import { Component } from '@angular/core'

@Component({
  templateUrl: './config-item-component-table.component.html',
  selector: 'app-config-item-component-table',
  styleUrls: ['./config-item-component-table.component.scss']
})

export class ConfigItemComponentTableComponent {
  public tags: { name: string, value: string }[] = [
    {
      name: "Ambiente",
      value: "Desarrollo"
    },
    {
      name: "Tier",
      value: "Frie"
    },
    {
      name: "Area",
      value: "TI"
    },
  ]
  constructor() {}
}