import { Component } from '@angular/core'
import { NgbModal } from '@ng-bootstrap/ng-bootstrap';
import { FormBuilder, FormGroup, Validators } from '@angular/forms';

@Component({
  selector: 'app-config-item',
  templateUrl: './config-item.component.html',
  styleUrls: ['./config-item.component.scss']
})

export class ConfigItemComponent {
  
  public tags: { name: string, value: string }[] = []

  public isAddingTags = false
  public submitted = false
  public tagSubmitted = false

  public ciForm = this.formBuilder.group({
    name: ["", [Validators.required]],
    ip:   ["", Validators.required],
    tags: [[]],
    tag: this.formBuilder.group({
      name: ["", [Validators.required]],
      value: ["",  [Validators.required]]
    }),
    isActive: [true]
  })

  constructor(private modalService: NgbModal, 
              private formBuilder: FormBuilder) {}

  openOpen(content: any) {
    this.modalService.open(content,{ centered: true });
  }

  addTag() {
    this.tagSubmitted = true
    if(this.ciForm.controls['tag'].invalid) {
      return
    }
    const name = this.ciForm.controls['tag']['controls']['name'].value!
    const value = this.ciForm.controls['tag']['controls']['value'].value!

    this.tags.push({name, value})

    this.ciForm.controls['tag'].reset()
    this.tagSubmitted = false
  }

  get f() { return this.ciForm.controls }

  get ff() { return this.ciForm.controls['tag']['controls'] }

  closeModal(modal: any) {
    // modal.close('Close click')
  }

  createCI() {
    this.submitted = true
    if(this.ciForm.invalid) {
      return
    }
  }

  hideAddTagInput() {
    this.isAddingTags = false
  }
  
  showAddTagInput() {
    this.isAddingTags = true
  }
}
