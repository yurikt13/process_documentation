import { Component } from '@angular/core'
import { NgbModal } from '@ng-bootstrap/ng-bootstrap';

@Component({
	selector: 'app-create-edit-component-group',
	templateUrl: './create-edit-component-group.component.html',
	styleUrls: ['./create-edit-component-group.component.scss']
})

export class CreateEditComponentGroupComponent {
	constructor(private modalService: NgbModal) {}

	openModal(content: any) {
    this.modalService.open(content,{ centered: true });
  }

	closeModal(modal: any) {

  }

	createGroup() {

  }
}