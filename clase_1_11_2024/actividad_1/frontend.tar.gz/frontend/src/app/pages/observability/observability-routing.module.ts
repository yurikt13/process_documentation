import { NgModule } from '@angular/core'
import { RouterModule, Routes } from '@angular/router';

import * as Containers from './containers/'

const routes: Routes = [
  {
    path: 'groups',
    component: Containers.ComponentGroupsComponent
  },
  {
    path: 'ci',
    component: Containers.ConfigItemComponent
  },
  {
    path: 'ci/:ciid/components',
    component: Containers.ConfigItemComponentComponent
  }
]

@NgModule({
  imports: [RouterModule.forChild(routes)],
  exports: [RouterModule]
})

export class ObservabiliteRoutingModule {}