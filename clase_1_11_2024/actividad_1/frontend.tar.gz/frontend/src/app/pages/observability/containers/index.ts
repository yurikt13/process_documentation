import { ComponentGroupsComponent }     from './component-groups/component-groups.component';
import { ConfigItemComponent }          from './confi-item/config-item.component';
import { ConfigItemComponentComponent } from './config-item-component/config-item-component.component';

export const containers = [
  ConfigItemComponent,
  ComponentGroupsComponent,
  ConfigItemComponentComponent,
]

export * from './component-groups/component-groups.component';
export * from './confi-item/config-item.component';
export * from './config-item-component/config-item-component.component';