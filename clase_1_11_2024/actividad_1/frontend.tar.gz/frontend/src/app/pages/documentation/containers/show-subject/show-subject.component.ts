import { Component, OnInit } from "@angular/core";
import { ActivatedRoute } from "@angular/router";
import { AuthService } from "src/app/account/services/auth.service";
import { FileService } from "src/app/pages/commercial/services/file.service";

@Component({
  templateUrl: './show-subject.component.html',
  selector: 'app-show-subject',
  styleUrls: ['./show-subject.component.scss']
})

export class ShowSubjectComponent implements OnInit {
  public subjectId:       string = ""
  public isLoadingInfo:   boolean = true
  public user:            any = {}
  public isLoadingUser:   boolean = true
  public files:           any[] = []

  constructor(private readonly authService: AuthService,
              private readonly fileService: FileService,
              private readonly activatedRoute: ActivatedRoute) {}

  ngOnInit(): void {
    this.activatedRoute.params.subscribe(data => {
      this.subjectId = data["id"]
      this.getUsersFiles(this.subjectId)
    })

    this.authService.me().subscribe(user => {
      this.user = user
      this.isLoadingUser = false
    })
  }

  private getUsersFiles(id: string) {
    this.isLoadingInfo = true
    this.fileService.getBySubject(id).subscribe(data => {
      this.files = data
      this.isLoadingInfo = false
    })
  }

  downloadFile(file: any) {
    window.open(`http://localhost:8080/api/file-service/files/${file._id}`)
  }

}