import { Component, OnInit } from "@angular/core";
import { Router } from "@angular/router";
import { AuthService } from "src/app/account/services/auth.service";

@Component({
  selector: "app-home",
  templateUrl: "./home.component.html",
  styleUrls: ["./home.component.scss"]
})

export class HomeComponent implements OnInit {

  public subjects: any[] = []
  public user: any = {}
  public isLoading: boolean = true

  constructor(private readonly authService: AuthService,
              private readonly router: Router) {}

  ngOnInit(): void {
    this.getUser()
  }

  getUser() {
    this.authService.me().subscribe(data => {
      this.user = data
      this.getSubjects(this.user._id)
    })
  }

  getSubjects(user: any) {
    this.isLoading = true
    this.authService.getAllSubjectsByUser(user).subscribe(data => {
      this.subjects = data
      this.isLoading = false
    })
  }

  goToSubject(path: string, subjectId: string) {
    this.router.navigate([`/pages/documentation/${path}/${subjectId}`])
  }

}