import { Component, OnInit } from "@angular/core";
import { FormBuilder, Validators } from "@angular/forms";
import { ActivatedRoute } from "@angular/router";
import { AuthService } from "src/app/account/services/auth.service";
import { FileService } from "src/app/pages/commercial/services/file.service";

@Component({
  templateUrl: './upload-documents.component.html',
  styleUrls: ['./upload-documents.component.scss'],
  selector: 'app-upload-documents'
})

export class UploadDocumentsComponent implements OnInit {

  public isUploadingFile: boolean = false
  public isLoadingInfo:   boolean = true
  public files:           any[] = []
  public subjectId:       string = ""
  public user:            any = {}
  public isLoadingUser:   boolean = true


  public fileForm = this.formBuilder.group({
    name:     ["", [Validators.required, Validators.minLength(5)]],
    filePath: [null, [Validators.required]],
    file:     [null, [Validators.required]]
  })

  constructor(private readonly formBuilder: FormBuilder, 
              private readonly fileService: FileService,
              private readonly authService: AuthService,
              private readonly activatedRoute: ActivatedRoute) {
                
              }


  ngOnInit(): void {

    this.activatedRoute.params.subscribe(data => {
      this.subjectId = data["id"]
      this.getUsersFiles(this.subjectId)
    })

    this.authService.me().subscribe(user => {
      this.user = user
      this.isLoadingUser = false
    })
  }

  onSubmit() {
    this.uploadFile()
  }

  onFileChange(event: any) {
    if (event.target.files && event.target.files.length) {
      const [file] = event.target.files;
      this.fileForm.controls["file"].setValue(file)
    }
  }

  downloadFile(file: any) {
    window.open(`http://localhost:8080/api/file-service/files/${file._id}`)
  }

  private uploadFile() { 
    this.isUploadingFile = true
    this.fileService.create({...this.fileForm.value, subject: this.subjectId, user: this.user._id}).subscribe(data => {
      this.getUsersFiles(this.subjectId)
      this.isUploadingFile = false
    })
  }

  private getUsersFiles(id: string) {
    this.isLoadingInfo = true
    this.fileService.getBySubject(id).subscribe(data => {
      this.files = data
      console.log(this.files)
      this.isLoadingInfo = false
    })
  }

}