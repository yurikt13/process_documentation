import { NgModule } from '@angular/core'
import { RouterModule, Routes } from '@angular/router';

import * as Containers from './containers/'

const routes: Routes = [
  {
    path: '',
    component: Containers.HomeComponent
  },
  {
    path: 'upload/:id',
    component: Containers.UploadDocumentsComponent
  },
  {
    path: 'subjects/:id',
    component: Containers.ShowSubjectComponent
  },
  { path: '', redirectTo: '/', pathMatch: 'full' },
]

@NgModule({
  imports: [RouterModule.forChild(routes)],
  exports: [RouterModule]
})

export class DocumentationRoutingModule {}