import { HomeComponent } from "./home/home.component";
import { ShowSubjectComponent } from "./show-subject/show-subject.component";
import { UploadDocumentsComponent } from "./upload-documents/upload-documents.component";

export const containers = [
  HomeComponent,
  UploadDocumentsComponent,
  ShowSubjectComponent
]

export * from "./show-subject/show-subject.component";
export * from "./home/home.component";
export * from "./upload-documents/upload-documents.component";