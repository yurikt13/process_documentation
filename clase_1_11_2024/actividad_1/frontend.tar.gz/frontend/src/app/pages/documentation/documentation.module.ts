import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { DocumentationRoutingModule } from './documentation-routing.module';
import { FormsModule, ReactiveFormsModule } from '@angular/forms'
import { CommonAndSharedModule } from 'src/app/common/common.module';

import * as Containers from './containers/'
import * as Components from './components/'

@NgModule({
  declarations: [
    ...Containers.containers,
    ...Components.components
  ],
  imports: [
    CommonModule,
    CommonAndSharedModule,
    DocumentationRoutingModule,
    FormsModule, 
    ReactiveFormsModule
  ],
  exports: []
})

export class DocumentationModule {}