import { Component } from "@angular/core";
import { AuthService } from "src/app/account/services/auth.service";

@Component({
  templateUrl: 'profile-header-card.component.html',
  selector: 'app-profile-header-card',
  styleUrls: ['./profile-header-card.component.scss']
})

export class ProfileHeaderCardComponent {
  public subjects: any[] = []
  public user: any = {}
  public isLoading: boolean = true

  constructor(private readonly authService: AuthService) {}

  ngOnInit(): void {
    this.getUser()
  }

  getUser() {
    this.authService.me().subscribe(data => {
      this.user = data
      this.isLoading = false
    })
  }
}