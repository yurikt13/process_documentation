import { ProfileCardComponent }       from "./profile-card/profile-card.component";
import { ProfileHeaderCardComponent } from "./profile-header-card/profile-header-card.component";
import { SkillListComponent }         from "./skill-list/skill-list.component";
import { UsersTableComponent }        from "./users-table/users-table.component";

export const components = [
  ProfileCardComponent,
  ProfileHeaderCardComponent,
  SkillListComponent,
  UsersTableComponent,
]

export * from "./skill-list/skill-list.component";
export * from "./profile-header-card/profile-header-card.component";
export * from "./profile-card/profile-card.component";
export * from "./users-table/users-table.component";