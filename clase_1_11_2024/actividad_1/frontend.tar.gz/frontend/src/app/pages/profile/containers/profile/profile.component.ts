import { Component } from "@angular/core";

@Component({
  templateUrl: './profile.component.html',
  selector: 'app-profile',
  styleUrls: ['./profile.component.scss']
})

export class ProfileComponent {
  constructor() {}
}