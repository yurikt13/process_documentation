import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormsModule, ReactiveFormsModule } from '@angular/forms'
import { NgbNavModule } from '@ng-bootstrap/ng-bootstrap';
import { CommonAndSharedModule } from 'src/app/common/common.module';

import { ProfileRoutingModule } from './profile-routing.module';

import * as Containers from './containers/'
import * as Components from './components/'
import { CommercialModule } from '../commercial/commercial.module';

@NgModule({
  declarations: [
    ...Containers.containers,
    ...Components.components
  ],
  imports: [
    CommonModule,
    CommonAndSharedModule,
    ProfileRoutingModule,
    FormsModule,
    NgbNavModule, 
    ReactiveFormsModule,
    CommercialModule
  ],
  exports: []
})

export class ProfileModule {}