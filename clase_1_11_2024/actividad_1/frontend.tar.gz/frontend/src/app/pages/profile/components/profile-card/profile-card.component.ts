import { Component, ElementRef, OnInit, ViewChild } from "@angular/core";
import { FormBuilder, Validators } from "@angular/forms";
import { NgbModal } from "@ng-bootstrap/ng-bootstrap";
import { AuthService } from "src/app/account/services/auth.service";
import { SWAL_SUBJECT_MESSAGES, SweetalertService } from "src/app/common/sweetalert/sweetalert.service";
import { SUBJECT_ATTRS } from "src/app/pages/commercial/services/ally.service";
import { ACTIONS_FORM } from "src/app/services/base.service";

@Component({
  selector: 'app-profile-card',
  templateUrl: './profile-card.component.html',
  styleUrls: ['./profile-card.component.scss']
})

export class ProfileCardComponent implements OnInit {
  public action!:             ACTIONS_FORM
  public ACTIONS_FORM =       ACTIONS_FORM
  public submitted!:          boolean
  public isLoading:           boolean = false
  public isLoadingUser:       boolean = true
  public isLoadingSubject:    boolean = true
  public allSubject:          any[] =   []
  public modalSelected:       string  = ''
  public user:                any = {}
  
  @ViewChild('createUpdateAllyModal', { static: true }) createUpdateAllyModal!: ElementRef

  constructor(private readonly modalService: NgbModal, 
              private readonly formBuilder: FormBuilder,
              private readonly authService: AuthService,
              private readonly sweetalertService: SweetalertService,
  ) {}

  ngOnInit(): void {
    this.authService.me().subscribe(user => {
      this.user = user
      this.isLoadingUser = false
    })
  }

  private getAllSubjects() {
    this.isLoadingSubject = true
    this.authService.getAllSubjects().subscribe(data => {
      this.allSubject = data
      this.isLoadingSubject = false
    })
  }
  
  openModal() {
    const action = ACTIONS_FORM.CREATE
    if(action === ACTIONS_FORM.CREATE) {
      // this.resetFormValues()
    }
    this.modalService.open(this.createUpdateAllyModal, { centered: true });
  }

  openModalCreateSubjet() {
    this.modalSelected = "CREATE"
    
    const action = ACTIONS_FORM.CREATE
    if(action === ACTIONS_FORM.CREATE) {
      // this.resetFormValues()
    }
    this.modalService.open(this.createUpdateAllyModal, { centered: true });
  }

  get f () {
    return this.allyForm.controls
  }

  public allyForm = this.formBuilder.group({
    uuid     :[""],
    isActive :[true],
    name     :["", [Validators.required]],
    code     :["", [Validators.required]]
  })

  execActionCreateOrUpdate() {
    this.submitted = true
    this.isLoading = true
    const payload: SUBJECT_ATTRS = {
      name: this.f['name'].value!,
      code: this.f['code'].value!
    }
    this.createSubjet(payload)
  }

  createSubjet(payload: SUBJECT_ATTRS) {
    this.authService.createSubject(payload).subscribe(data => {
      this.isLoading
      this.sweetalertService.successmsg(SWAL_SUBJECT_MESSAGES.successCreated)
      this.isLoading = false
      this.allyForm.reset()
    })
  }

  openModalSelectSubjet() {
    this.modalSelected = "SELECT"
    this.modalService.open(this.createUpdateAllyModal, { centered: true });
    this.getAllSubjects()
  }


  closeModal(modal: any) {
    modal.close()
  }

  selectObject(subject: any) {
    this.authService.vinculateSubjectToUser({ user: this.user._id, subject: subject._id}).subscribe(data => {
      this.sweetalertService.successmsg(SWAL_SUBJECT_MESSAGES.successLinked)
    }, (error) => {
      this.sweetalertService.errormsg('No se pudo seleccionar esta asignatura')
    })
  }

}