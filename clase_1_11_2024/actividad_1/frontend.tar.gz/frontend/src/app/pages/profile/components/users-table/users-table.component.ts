import { Component } from "@angular/core";
import { AuthService } from "src/app/account/services/auth.service";

@Component({
  templateUrl: './users-table.component.html',
  selector: 'app-users-table',
  styleUrls: ['./users-table.component.scss']
})

export class UsersTableComponent {
  public subjects: any[] = []
  public user: any = {}
  public isLoading: boolean = true

  constructor(private readonly authService: AuthService) {}

  ngOnInit(): void {
    this.getUser()
  }

  getUser() {
    this.authService.me().subscribe(data => {
      this.user = data
      if(this.user.roles.includes('STUDENT') || this.user.roles.includes('TEACHER')) {
        this.getSubjects(this.user._id)
      } else {
        this.getAllSubjects()
      }
    })
  }

  getSubjects(user: any) {
    this.isLoading = true
    this.authService.getAllSubjectsByUser(user).subscribe(data => {
      this.subjects = data.map((d: any) => {
        return {
          name: d.subject.name,
          code: d.subject.code
        }
      })
      this.isLoading = false
    })
  }

  getAllSubjects() {
    this.isLoading = true
    this.authService.getAllSubjects().subscribe(data => {
      this.subjects = data
      this.isLoading = false
    })
  }
}