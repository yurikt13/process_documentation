import { ProfileComponent } from "./profile/profile.component";

export const containers = [
  ProfileComponent
]

export * from "./profile/profile.component";