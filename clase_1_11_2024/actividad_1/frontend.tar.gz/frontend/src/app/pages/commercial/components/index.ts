import { AllianceCardComponent }       from "./alliance-card/alliance-card.component";
import { AlliancesTableComponent }     from "./alliances-table/alliances-table.component";
import { AlliesTableComponent }        from "./allies-table/allies-table.component";
import { CreateEditAllianceComponent } from "./create-edit-alliance/create-edit-alliance.component";
import { CreateEditAllyComponent }     from "./create-edit-ally/create-edit-ally.component";

export const Components = [
  AllianceCardComponent,
  AlliancesTableComponent,
  AlliesTableComponent,
  CreateEditAllyComponent,
  CreateEditAllianceComponent,
]

export * from "./alliances-table/alliances-table.component";
export * from "./allies-table/allies-table.component";
export * from "./create-edit-alliance/create-edit-alliance.component";
export * from "./create-edit-ally/create-edit-ally.component";
export * from "./alliance-card/alliance-card.component";