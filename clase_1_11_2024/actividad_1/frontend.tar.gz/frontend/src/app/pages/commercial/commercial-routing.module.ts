import { NgModule } from '@angular/core'
import { RouterModule, Routes } from '@angular/router';

import * as Containers from './containers'

const routes: Routes = [
  {
    path: 'allies',
    component: Containers.AlliesHomeComponent
  },
  {
    path: 'allies/:term/alliances',
    component: Containers.AlliancesHomeComponent
  },
  {
    path: 'allies/:term/alliances/:id',
    component: Containers.ShowAllianceComponent
  }
]

@NgModule({
  imports: [RouterModule.forChild(routes)],
  exports: [RouterModule]
})

export class CommercialRoutingModule {}