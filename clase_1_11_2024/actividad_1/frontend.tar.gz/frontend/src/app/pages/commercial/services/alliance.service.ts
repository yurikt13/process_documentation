import { Injectable } from '@angular/core';
import { BaseService } from 'src/app/services/base.service';
import { API_RESOURCES } from 'src/helpers/api.resources';

export interface ALLIANCE_ATTRS {
  _id:          string
  uuid:         string
  internalCode: string
  name:         string
  modules:      string[]
  responsable:  string
  ally:         string
  createdAt:    string
  isActive:     boolean
}

export interface ALLIANCE_PAYLOAD {
  internalCode: string
  name:         string
  modules?:     string[]
  responsable?: string
  ally:         string
}

export const CREARTE_ALLIANCE_REQUIRED_VALUES: string[] = [ "internalCode", "name", "ally" ]

export const UPDATE_ALLIANCE_REQUIRED_VALUES: string[] = [ "_id", "internalCode", "name" ]

export interface UPDATE_ALLIANCE_ATTRS {
  internalCode?: string
  name?:         string
  modules:       string[]
  responsable?:  string
}

export enum ALLIANCE_STATUS {
  ACTIVE   = 'active',
  INACTIVE = 'active'
}

@Injectable({
  providedIn: 'root'
})

export class AllianceService extends BaseService {
  create(payload: ALLIANCE_PAYLOAD) {
    return this.httpPost(API_RESOURCES.allianceService.createAlliance(), payload)
  }

  update(payload: UPDATE_ALLIANCE_ATTRS, term: string) {
    return this.httpPost(API_RESOURCES.allianceService.updateAlliance(term), payload)
  }

  getByTerm(term: string) {
    return this.httpGet(API_RESOURCES.allianceService.getAllianceByTerm(term))
  }

  getAll() {
    return this.httpGet(API_RESOURCES.allianceService.getAllianceAllies())
  }

  active(term: string) {
    this.toggleIsActive(term, ALLIANCE_STATUS.ACTIVE)
  }

  inactive(term: string) {
    return this.toggleIsActive(term, ALLIANCE_STATUS.INACTIVE)
  }

  private toggleIsActive(term: string, status: ALLIANCE_STATUS) {
    return this.httpPatch(API_RESOURCES.allianceService.toggleIsActive(term, status), {})
  }
}