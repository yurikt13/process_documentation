import { Component, Output, EventEmitter, ViewChild, ElementRef } from "@angular/core";
import { FormBuilder, Validators } from "@angular/forms";
import { NgbModal } from '@ng-bootstrap/ng-bootstrap';
import { ALLY_ATTRS, AllyService } from "../../services/ally.service";
import { ACTIONS_FORM } from "src/app/services/base.service";

@Component({
  templateUrl: './create-edit-ally.component.html',
  selector: 'app-create-edit-ally',
  styleUrls: ['./create-edit-ally.component.scss']
})

export class CreateEditAllyComponent {
  @Output('addAlly') addAlly: EventEmitter<ALLY_ATTRS> = new EventEmitter<ALLY_ATTRS>()
  @Output('updateAllyEvent') updateAllyEvent: EventEmitter<ALLY_ATTRS> = new EventEmitter<ALLY_ATTRS>()
  @ViewChild('createUpdateAllyModal', { static: true }) createUpdateAllyModal!: ElementRef

  public action!:             ACTIONS_FORM
  public submitted!:          boolean
  public isLoading:           boolean = false
  public ACTIONS_FORM =       ACTIONS_FORM
  public modal:               any

  public allyForm = this.formBuilder.group({
    _id      :[""],
    uuid     :[""],
    isActive :[true],
    name     :["", [Validators.required]],
    document :["", [Validators.required]]
  })

  constructor(private readonly modalService: NgbModal, 
              private readonly formBuilder: FormBuilder,
              private readonly allyService: AllyService) {
    
  }

  get f () {
    return this.allyForm.controls
  }

  openModal(action: ACTIONS_FORM) {
    this.action = action
    if(this.action === ACTIONS_FORM.CREATE) {
      this.resetFormValues()
    }
    this.modalService.open(this.createUpdateAllyModal, { centered: true });
  }

	closeModal(modal: any) {
    modal.close()
  }

	createAlly(payload: ALLY_ATTRS) {
    this.allyService.create(payload).subscribe((data: ALLY_ATTRS) => {
      this.isLoading = false
      this.cleanForm()
      this.addAlly.emit({document: data.document, name: data.name, isActive: data.isActive, uuid: data.uuid})
      this.modalService.dismissAll()
    })
  }

  updateAlly(payload: ALLY_ATTRS) {
    this.allyService.update(payload._id!, payload).subscribe(data => {
      console.log(data)
    }) 
  }

  execActionCreateOrUpdate() {
    this.submitted = true
    this.isLoading = true
    const payload: ALLY_ATTRS = {
      name:     this.f['name'].value!,
      document: this.f['document'].value!
    }
    if(this.action === ACTIONS_FORM.CREATE) {
      this.createAlly(payload)
    } else if (this.action === ACTIONS_FORM.UPDATE) {
      this.updateAlly(payload)
    }

  }

  openformToUpdateAlly(ally: ALLY_ATTRS) {
    this.setUpForm(ally)
    this.openModal(ACTIONS_FORM.UPDATE)
  }
  
  private cleanForm() {
    this.allyForm.reset()
  }

  private setUpForm(ally: ALLY_ATTRS) {
    this.f['_id'].setValue(ally._id!)
    this.f['uuid'].setValue(ally.uuid!)
    this.f['name'].setValue(ally.name)
    this.f['isActive'].setValue(ally.isActive!)
    this.f['document'].setValue(ally.document)
  }

  private resetFormValues() {
    this.f['_id'].setValue("")
    this.f['uuid'].setValue("")
    this.f['name'].setValue("")
    this.f['document'].setValue("")
    this.f['isActive'].setValue(true)
  }
}