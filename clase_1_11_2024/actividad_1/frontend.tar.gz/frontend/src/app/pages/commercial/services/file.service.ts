import { Injectable } from '@angular/core';
import { BaseService } from 'src/app/services/base.service';
import { API_RESOURCES } from 'src/helpers/api.resources';

@Injectable({
  providedIn: 'root'
})

export class FileService extends BaseService {

  create(payload: any) {
    const formData: FormData = new FormData()
    formData.append('file', payload.file)
    formData.append('name', payload.name)
    formData.append('user', payload.user)
    formData.append('subject', payload.subject)
    return this.httpPost(API_RESOURCES.fileService.createFile(), formData)
  }

  getById(term: string) {
    return this.httpGet(API_RESOURCES.fileService.getFileById(term))
  }

  getByUser() {
    return this.httpGet(API_RESOURCES.fileService.getFilesByUser())
  }
  
  getBySubject(id: string) {
    return this.httpGet(API_RESOURCES.fileService.getFilesBySubject(id))
  }
  
}