import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';

import { FormsModule, ReactiveFormsModule } from '@angular/forms'
import { CommonAndSharedModule } from 'src/app/common/common.module';
import { CommercialRoutingModule } from './commercial-routing.module';

import * as Components from './components'
import * as Containers from './containers'

@NgModule({
  declarations: [
    ...Containers.containers,
    ...Components.Components
  ],
  imports: [
    CommonModule,
    CommonAndSharedModule,
    CommercialRoutingModule,
    FormsModule, 
    ReactiveFormsModule
  ],
  exports: [ Components.AlliancesTableComponent ]
})

export class CommercialModule {}