import { Component } from '@angular/core'

@Component({
  templateUrl: './show-alliance.component.html',
  selector: 'show-alliance',
  styleUrls: ['./show-alliance.component.scss']
})

export class ShowAllianceComponent {
  constructor() {}
}