import { Component, ElementRef, EventEmitter, Output, ViewChild } from "@angular/core";
import { FormBuilder, FormGroup, Validators } from "@angular/forms";
import { NgbModal } from "@ng-bootstrap/ng-bootstrap";
import { ActivatedRoute } from '@angular/router'
import { ALLIANCE_ATTRS, ALLIANCE_PAYLOAD, CREARTE_ALLIANCE_REQUIRED_VALUES, AllianceService, UPDATE_ALLIANCE_REQUIRED_VALUES } from "../../services/alliance.service";
import { ACTIONS_FORM } from "src/app/services/base.service";

interface CreateEditActionsTable {
  [ key: string ]: (payload: any) => void
}

interface RequiredPayloadKeys {
  [ key: string ]: string[]
}

@Component({
  selector: 'app-create-edit-alliance',
  templateUrl: 'create-edit-alliance.component.html',
  styleUrls: ['./create-edit-alliance.component.scss']
})

export class CreateEditAllianceComponent {
  @Output('addAlliance') addAlliance:                        EventEmitter<ALLIANCE_ATTRS> = new EventEmitter<ALLIANCE_ATTRS>()
  @Output('updateAllinaceEvent') updateAllinaceEvent:        EventEmitter<ALLIANCE_ATTRS> = new EventEmitter<ALLIANCE_ATTRS>()
  @ViewChild('createUpdateAllinaceModal', { static: true }) 
  createUpdateAllinaceModal!:                                ElementRef

  public ACTIONS_FORM = ACTIONS_FORM
  public action!: ACTIONS_FORM
  public submitted!: boolean
  public isLoading:  boolean = false
  public alliaceForm = this.formBuilder.group({
    _id:          [""],
    uuid:         [""],
    internalCode: ["", [Validators.required]],
    name:         ["", [Validators.required]],
    modules:      [""],
    responsable:  [""],
    ally:         ["", [Validators.required]],
    isActive:     [true]
  })

  private createEditActionsTable: CreateEditActionsTable = {
    [ACTIONS_FORM.CREATE]: this.createAlliance.bind(this),
    [ACTIONS_FORM.UPDATE]: this.updateAlliance.bind(this)
  }

  private requiredPayloadKeys: RequiredPayloadKeys = {
    [ACTIONS_FORM.CREATE]: CREARTE_ALLIANCE_REQUIRED_VALUES,
    [ACTIONS_FORM.UPDATE]: UPDATE_ALLIANCE_REQUIRED_VALUES
  }

  constructor(private readonly modalService: NgbModal, 
              private readonly formBuilder: FormBuilder, 
              private readonly activatedRoute:ActivatedRoute,
              private readonly allianceService: AllianceService) {
    this.activatedRoute.params.subscribe(params => {
      this.alliaceForm.controls['ally'].setValue(params['term'])
    })
  }

  get f () {
    return this.alliaceForm.controls
  }

  openModal(action: ACTIONS_FORM) {
    this.action = action
    if(this.action === ACTIONS_FORM.CREATE) {
      this.resetFormValues()
    }
    this.modalService.open(this.createUpdateAllinaceModal, { centered: true });
  }

  openCreateUpdateAllinaceModal(alliance: ALLIANCE_ATTRS) {
    this.setUpForm(this.alliaceForm, alliance)
    this.openModal(ACTIONS_FORM.UPDATE)
  }
  
  execActionCreateOrUpdate() {
    this.submitted = true
    this.isLoading = true
    const payload = this.getDataFromForm<ALLIANCE_PAYLOAD>(this.alliaceForm, this.requiredPayloadKeys[this.action])
    this.createEditActionsTable[this.action](payload)
  }

  closeModal(modal: any) {
    modal.close()
  }

  createAlliance(payload: any) {
    this.allianceService.create(payload).subscribe((data: ALLIANCE_ATTRS) => {
      this.isLoading = false
      this.cleanForm()
      this.addAlliance.emit(data)
      this.modalService.dismissAll()
    })
  }

  updateAlliance(payload: any) {
    this.allianceService.update(payload, payload._id).subscribe((data: ALLIANCE_ATTRS) => {
      this.isLoading = false
      this.cleanForm()
      this.addAlliance.emit(data)
      this.modalService.dismissAll()
    })
  }

  private cleanForm() {
    this.alliaceForm.reset()
  }

  private resetFormValues() {
    this.f['_id'].setValue("")
    this.f['uuid'].setValue("")
    this.f['name'].setValue("")
    this.f['internalCode'].setValue("")
    this.f['isActive'].setValue(true)
  }

  private setUpForm(form: FormGroup, info: { [key: string]: any}) {
    const formKeys = Object.keys(form.value)
    formKeys.forEach((formKey: string) => {
      form.controls[formKey].setValue(info[formKey])
    })
  }

  private getDataFromForm<T>(form: FormGroup, requiredKeys: string[] ): T {
    let data: { [key: string]: any } = { } 
    requiredKeys.forEach((key) => {
      data[key] = form.controls[key].value
    })
    return data as T
  }
}