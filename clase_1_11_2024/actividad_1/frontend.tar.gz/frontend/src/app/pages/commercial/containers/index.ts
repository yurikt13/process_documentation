import { AlliancesHomeComponent } from "./alliances-home/alliances-home.component";
import { AlliesHomeComponent }    from "./allies-home/allies-home.component";
import { ShowAllianceComponent }  from "./show-alliance/show-alliance.component";

export const containers = [
  AlliancesHomeComponent,
  AlliesHomeComponent,
  ShowAllianceComponent
]

export * from "./alliances-home/alliances-home.component";
export * from "./allies-home/allies-home.component";
export * from "./show-alliance/show-alliance.component";