import { Component } from "@angular/core";

@Component({
  templateUrl: './alliance-card.component.html',
  selector: 'app-alliance-card',
  styleUrls: ['./alliance-card.component.scss']
})

export class AllianceCardComponent {
  constructor() {}
}