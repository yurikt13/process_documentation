import { Component, ViewChild } from '@angular/core'
import { ALLY_ATTRS, AllyService } from '../../services/ally.service'
import { CreateEditAllyComponent } from '../../components';

@Component({
  templateUrl: './allies-home.component.html',
  selector: 'app-allies-home',
  styleUrls: ['./allies-home.component.scss']
})

export class AlliesHomeComponent {

  public allies: ALLY_ATTRS[] = []
  @ViewChild(CreateEditAllyComponent, { static: true }) createEditAllyComponent!: CreateEditAllyComponent;

  constructor(private readonly allyService: AllyService) {}

  ngOnInit(): void {
    this.loadInfo()
  }

  loadInfo() {
    this.allyService.getAll().subscribe((data: ALLY_ATTRS[]) => {
      this.allies = data
    })
  }

  addAlly(ally: any) {
    this.allies.push(ally)
  }

  openUpdateAlly(ally: ALLY_ATTRS) {
    this.createEditAllyComponent.openformToUpdateAlly(ally)
  }

  updateAllyEvent(ally: ALLY_ATTRS) {
    
  }
}