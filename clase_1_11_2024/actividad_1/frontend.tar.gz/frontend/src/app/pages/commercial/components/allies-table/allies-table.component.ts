import { Component, Input, EventEmitter, Output } from "@angular/core";
import { ALLY_ATTRS } from "../../services/ally.service";
import { RouterService } from 'src/app/services/router.service';
import { PAGES_RESOURCES } from "src/helpers/pages.resources";

@Component({
  templateUrl: 'allies-table.component.html',
  styleUrls: ['./allies-table.component.scss'],
  selector: 'app-allies-table'
})

export class AlliesTableComponent  {
  @Input('allies') allies: ALLY_ATTRS[] = []
  @Output('openUpdateAlly') openUpdateAlly: EventEmitter<any> = new EventEmitter<any>()
  
  constructor(private readonly routerService: RouterService) {}

  updateAlly(ally: ALLY_ATTRS) {
    this.openUpdateAlly.emit(ally)
  }

  goToShowAlliances(id: string) {
    this.routerService.navigate(PAGES_RESOURCES.alliancesHome(id))
  }

}