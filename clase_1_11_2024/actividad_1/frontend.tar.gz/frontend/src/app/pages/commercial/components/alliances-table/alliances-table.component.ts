import { Component, Input, Output, EventEmitter } from "@angular/core";
import { ALLIANCE_ATTRS } from "../../services/alliance.service";

@Component({
  templateUrl: './alliances-table.component.html',
  selector: 'app-alliances-table',
  styleUrls: ['./alliances-table.component.scss']
})

export class AlliancesTableComponent {
  @Input('alliances') alliances:                    ALLIANCE_ATTRS[] = []
  @Output('openUpdateAlliance') openUpdateAlliance: EventEmitter<ALLIANCE_ATTRS> = new EventEmitter<ALLIANCE_ATTRS>()
  
  constructor() {}
  
  updateAlliance(alliance: ALLIANCE_ATTRS) {
    this.openUpdateAlliance.emit(alliance)
  }

}