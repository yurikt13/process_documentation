import { Injectable } from '@angular/core';
import { BaseService } from 'src/app/services/base.service';
import { API_RESOURCES } from 'src/helpers/api.resources';

export interface ALLY_ATTRS {
  _id?      : string
  uuid?     : string
  name      : string
  document  : string
  isActive? : boolean
}

export interface SUBJECT_ATTRS {
  _id?      : string
  uuid?     : string
  name      : string
  code      : string
  isActive? : boolean
}

export interface UPDATE_ALLY_ATTRS {
  name?      : string
  document?  : string
}

export enum ALLY_STATUS {
  ACTIVE   = 'active',
  INACTIVE = 'active'
}

@Injectable({
  providedIn: 'root'
})

export class AllyService extends BaseService {

  create(payload: ALLY_ATTRS) {
    return this.httpPost(API_RESOURCES.allyService.createAlly(), payload)
  }

  update(allyId: string, payload: UPDATE_ALLY_ATTRS) {
    return this.httpPost(API_RESOURCES.allyService.updateAlly(allyId), payload)
  }

  getByTerm(term: string) {
    return this.httpGet(API_RESOURCES.allyService.getAllyByTerm(term))
  }

  getAll() {
    return this.httpGet(API_RESOURCES.allyService.getAllAllies())
  }

  active(term: string) {
    this.toggleIsActive(term, ALLY_STATUS.ACTIVE)
  }

  inactive(term: string) {
    return this.toggleIsActive(term, ALLY_STATUS.INACTIVE)
  }

  private toggleIsActive(term: string, status: ALLY_STATUS) {
    return this.httpPatch(API_RESOURCES.allyService.toggleIsActive(term, status), {})
  }
}