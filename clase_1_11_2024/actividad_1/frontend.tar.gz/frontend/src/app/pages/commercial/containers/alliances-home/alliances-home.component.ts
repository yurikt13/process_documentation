import { Component, OnInit, ViewChild } from "@angular/core";
import { ALLIANCE_ATTRS, AllianceService } from "../../services/alliance.service";
import { CreateEditAllianceComponent } from "../../components";

@Component({
  templateUrl: './alliances-home.component.html',
  selector: 'app-alliances-home',
  styleUrls: ['./alliances-home.component.scss']
})

export class AlliancesHomeComponent implements OnInit {
  @ViewChild(CreateEditAllianceComponent, { static: true }) 
  createEditAllianceComponent!: CreateEditAllianceComponent
  
  public alliances:             ALLIANCE_ATTRS[] = []
  public isLoadingAlliances:    boolean = true
  constructor(private allianceService: AllianceService) {}
  
  ngOnInit(): void {
    this.loadInfo()
  }

  loadInfo() {
    this.isLoadingAlliances = true
    this.allianceService.getAll().subscribe((data: ALLIANCE_ATTRS[]) => {
      this.alliances = data
      this.isLoadingAlliances = false
    }, (error) => {
      this.isLoadingAlliances = false
    })
  }

  addAlliance(alliance: any) {
    this.alliances.push(alliance)
  }

  openUpdateAlliance(alliance: ALLIANCE_ATTRS) {
    this.createEditAllianceComponent.openCreateUpdateAllinaceModal(alliance)
  }
}