import { NgModule } from '@angular/core'
import { CommonModule } from '@angular/common'
import { NgbDropdownModule, NgbNavModule } from '@ng-bootstrap/ng-bootstrap';
import { LightboxModule } from 'ngx-lightbox';
import { BasicTableComponent } from './basic-table/basic-table.component'
import { NgApexchartsModule } from 'ng-apexcharts';
import { TagComponent } from './tag/tag.component';
import { LoaderComponent } from './loader/loader.component';

@NgModule({
  imports: [
    CommonModule,
    NgbDropdownModule, 
    NgbNavModule,
    LightboxModule,
    NgApexchartsModule
  ],
  declarations: [
    BasicTableComponent,
    TagComponent,
    LoaderComponent
  ],
  exports: [
    BasicTableComponent,
    TagComponent,
    LoaderComponent
  ]
})

export class CommonAndSharedModule {}