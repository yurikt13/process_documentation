import { Component } from '@angular/core'

@Component({
  selector: 'app-loader',
  template: `
    <div class="row">
      <div class="col-xl-12">
        <div class="">
          <p class="placeholder-glow">
            <span class="placeholder col-12"></span>
          </p>
          <p class="placeholder-wave">
            <span class="placeholder col-12"></span>
          </p>
          <p class="placeholder-wave">
            <span class="placeholder col-12"></span>
          </p>
          <p class="placeholder-wave">
            <span class="placeholder col-12"></span>
          </p>
        </div>
      </div>
    </div>
  `
})
export class LoaderComponent {
  constructor() {}
}