import { Component, Input } from '@angular/core'
import { NgbModal } from '@ng-bootstrap/ng-bootstrap';
import { RouterService } from 'src/app/services/router.service';
import { PAGES_RESOURCES } from 'src/helpers/pages.resources';

@Component({
  templateUrl: './basic-table.component.html',
  selector: 'app-basic-table',
  styleUrls: ['./basic-table.component.scss']
})

export class BasicTableComponent {
  @Input('headers') headers: string[] = [ "Nombre", "Ip", "office", "age", "date", "salary"]
  public tableData = [
    {
      _id: "1",
      name: 'server.local.k8s',
      position: '10.10.10.10',
      office: [
        { name: 'Ambiente', value: 'Producción' },
        { name: 'Tier', value: 'Basic' },
      ],
      age: 3,
      date: '2018/12/04',
      salary: '$11700'
    }
  ];
  constructor(private readonly modalService: NgbModal, 
              private readonly routerService: RouterService) {}

  toToCiComponents(id: string) {
    this.routerService.navigate(PAGES_RESOURCES.ciComponentsHome(id))
  }

}