import * as Crypto from 'crypto-js'
import { environment } from 'src/environments/environment'
import { Injectable } from '@angular/core'

@Injectable()
export class CryptoLibrary {
  private key!: string
  
  constructor() {
    this.key = environment.keyCrypto
  }

  public encrypt(value: string): string {
    return Crypto.AES.encrypt(value, this.getKey()).toString()
  }

  public decrypt(encrypted: string): string {
    return Crypto.AES.decrypt(encrypted, this.getKey()).toString(Crypto.enc.Utf8)
  }

  private getKey(): string {
    return this.key
  }

}