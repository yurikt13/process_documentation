interface PAGES_PATH_INTERFACE {
  [ key: string ]: (...args: any[]) => string
}

export const PAGES_RESOURCES: PAGES_PATH_INTERFACE = {
  dashboard:        () => 'pages/dashboard',
  login:            () => '/auth/login',
  alliancesHome:    (id: string) => `pages/commercial/allies/${id}/alliances`,
  ciComponentsHome: (id: string) => `/pages/observability/ci/${id}/components`
}