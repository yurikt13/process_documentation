import { ALLIANCE_STATUS } from "src/app/pages/commercial/services/alliance.service"
import { ALLY_STATUS } from "src/app/pages/commercial/services/ally.service"

interface API_RESOURCES_INTERFACE_PATH {
  [ key: string ]: (...args: any[]) => string
}

interface API_RESOURCES_INTERFACE {
  authService:            API_RESOURCES_INTERFACE_PATH
  eventManagementService: API_RESOURCES_INTERFACE_PATH
  allianceService:        API_RESOURCES_INTERFACE_PATH
  allyService:            API_RESOURCES_INTERFACE_PATH
  fileService:            API_RESOURCES_INTERFACE_PATH
  subjectsService:        API_RESOURCES_INTERFACE_PATH
  subjectUserService:     API_RESOURCES_INTERFACE_PATH
}

export const API_RESOURCES: API_RESOURCES_INTERFACE = {
  authService: {
    signup:          () => "auth-service/auth/signup",
    signin:          () => "auth-service/auth/signin",
    signout:         () => "auth-service/auth/signout",
    isAuthenticated: () => "auth-service/auth/authenticate",
    me:              () => "auth-service/auth/me"
  },
  allyService: {
    getAllAllies:   () => `alliance-service/ally`,
    getAllyByTerm:  (term: string) => `alliance-service/ally/${term}`,
    createAlly:     () => `alliance-service/ally`,
    updateAlly:     (term: string) => `alliance-service/ally/${term}`,
    toggleIsActive: (term: string, status: ALLY_STATUS) => `alliance-service/ally/${term}/${status}`
  },
  allianceService: {
    getAllianceAllies: () => `alliance-service/ally-alliance`,
    getAllianceByTerm: (term: string) => `alliance-service/ally-alliance/${term}`,
    createAlliance:    () => `alliance-service/ally-alliance`,
    updateAlliance:    (term: string) => `alliance-service/ally-alliance/${term}`,
    toggleIsActive:    (term: string, status: ALLIANCE_STATUS) => `alliance-service/ally-alliance/${term}/${status}`
  },
  eventManagementService: {

  },
  fileService: {
    createFile:        () => `file-service/files`,
    getFileById:       (term: string) => `file-service/files/${term}`,
    getFilesByUser:    () => `file-service/files/user`,
    getFilesBySubject: (id: string) => `file-service/files/subject/${id}`,
  },
  subjectsService: {
    create:               () => `auth-service/subjects`,
    getById:              (term: string) => `auth-service/subjects/id/${term}`,
    getAll:               () => `auth-service/subjects`,
    getAllSubjectsByUser: (user: string) => `auth-service/subjects/user/${user}`,
  },
  subjectUserService: {
    create:               () => `auth-service/subject-user`,
    getAllByUser:         (user: string) => `auth-service/subject-user/user/${user}`,
  }
}